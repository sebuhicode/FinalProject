﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.Models;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;

namespace FinalProjects.Controllers
{
    public class TermsController : Controller
    {
        private readonly FrontContext _context;
        public TermsController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            TermsVm termsVm = new TermsVm
            {
                Terms = _context.Terms.ToList(),
                TermsItems = _context.TermsItems.ToList()
            };
            
            return View(termsVm);
        }
    }
}