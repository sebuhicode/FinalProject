﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FinalProjects.Migrations
{
    public partial class productsAddedToSubCatgeory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
