﻿using FinalProjects.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProjects.ViewsModel
{
    public class ProductVm
    {
        public Product Product { get; set; }

        public IEnumerable<City> Cities { get; set; }

        public AppUser AppUser { get; set; }

        public IEnumerable<Subcategory> Subcategories { get; set; }

        public IEnumerable<Category> Categories { get; set; }

        public IEnumerable<ProductImage> ProductImages { get; set; }


    }
}
