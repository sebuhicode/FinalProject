﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Mvc;

namespace FinalProjects.Controllers
{
    public class SearchController : Controller
    {
        private readonly FrontContext _context;
        public SearchController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index(int? id )
        {
            if (id == null) return NotFound();


            HomeIndexVm homeIndexVm = new HomeIndexVm
            {
                Products = _context.Products.Where(a => a.Subcategory.CategoryID == id),
                ProductImages = _context.ProductImages.ToList(),
            };
            return View(homeIndexVm);
        }
    }
}