﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.Models;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Identity;

namespace FinalProjects.Controllers
{
    public class HomeController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;

        public HomeController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index(int page = 1)
        {
            var skipCount = (int)((page - 1) * 20);
          

            ViewData["active_page"] = page;

            HomeIndexVm homeIndexVm = new HomeIndexVm
            {
                Cities = _context.Cities.ToList(),
                Categories = _context.Categories.ToList(),
                Products = _context.Products.OrderByDescending(d=>d.CreatedAt).Where(p=> p.VezID == 1).Skip(skipCount).Take(20).ToList(),
                ProductImages = _context.ProductImages.ToList(),
                FavoriteProducts = _context.FavoriteProducts.ToList(),
            };

            ViewData["elan"] = _context.Products.ToList().Count();

            int seeCount = 0;

            foreach (var pro in _context.Products)
            {
                seeCount += pro.SeeCount;
            }

            ViewData["baxis"] = seeCount;

            return View(homeIndexVm);
        }

    

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
