﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.DAL;
using FinalProjects.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;


namespace FinalProjects.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class ProductsController : Controller
    {
        private readonly FrontContext _context;

        public ProductsController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index(int page = 1)
        {
            var skipCount = (int)((page - 1) * 5);
            var products = _context.Products.OrderByDescending(p=> p.CreatedAt).Skip(skipCount).Take(5).ToList();

            ViewData["total_customer_count"] = _context.Products.ToList().Count();
            ViewData["active_page"] = page;

            ViewData["status"] = _context.Veziyyets.ToList();
            ViewData["image"] = _context.ProductImages.ToList();
            ViewData["category"] = _context.Categories.ToList();

            return View(products);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products.FindAsync(id);

            if (product == null) return NotFound();

            ViewData["status"] = _context.Veziyyets.ToList();

            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Product product)
        {
            Product ProductFromDb = await _context.Products.FindAsync(id);
            ProductFromDb.VezID = product.VezID;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}