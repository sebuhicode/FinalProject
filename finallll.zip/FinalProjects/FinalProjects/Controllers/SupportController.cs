﻿using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.Models;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Identity;
using System;

namespace FinalProjects.Controllers
{
    public class SupportController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;

        public SupportController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task <IActionResult> Index()
        {
            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);
            var Supp = _context.TexnikiDesteks.Where(s => s.UserID == activUser.Id);
            ViewData["status"] = _context.Veziyyets.ToList();
            return View(Supp);
        }


        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TexnikiDestek destek)
        {
            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);

            destek.CreatedAT = DateTime.Now;
            destek.UserID = activUser.Id;
            destek.VezID = 2;
            await _context.TexnikiDesteks.AddAsync(destek);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index","Support");
        }


        public IActionResult Chat(int? id)
        {
            if (id == null) return NotFound();
            ViewData["destek"] = _context.TexnikiDesteks.Find(id);
            ViewData["sms"] = _context.Messages.Where(m => m.TexnikiDestekID == id).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Chat(int id,Message message)
        {
            if (!ModelState.IsValid)
            {
                return View(message);
            }
            ViewData["sms"] = _context.Messages.Where(m => m.TexnikiDestekID == id).ToList();
            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);


            Message ms = new Message
            {
                Msj = message.Msj,
                TexnikiDestekID = id,
                UserID = activUser.Id,
                CreatedAT = DateTime.Now
            };

            TexnikiDestek destek = _context.TexnikiDesteks.Find(id);
            destek.VezID = 2;

            await _context.Messages.AddAsync(ms);

            await _context.SaveChangesAsync();

            return RedirectToAction($"Chat", "Support");
        }

    }
}