﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.DAL;
using FinalProjects.Models;

namespace FinalProjects.ViewsModel
{
    public class TermsVm
    {
        public  IEnumerable<Terms>  Terms{ get; set; }

        public  IEnumerable<TermsItem>  TermsItems{ get; set; }

    }
}
