﻿using System.ComponentModel.DataAnnotations;

namespace FinalProjects.Models
{
    public class TermsItem
    {
        public int Id { get; set; }

        public int CountTerms { get; set; }

        [StringLength(1000)]
        public string Text { get; set; }

        public int TermsID { get; set; }

        public virtual Terms Terms { get; set; }
    }
}
