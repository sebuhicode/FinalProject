﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.DAL;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.ViewsModel;
using FinalProjects.Models;
using FinalProjects.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;

namespace FinalProjects.Controllers
{
    public class NewController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;
        private readonly UserManager<AppUser> _userManager;

        public NewController(FrontContext context, IHostingEnvironment env, UserManager<AppUser> userManager)
        {
            _context = context;
            _env = env;
            _userManager = userManager;
        }

        public IActionResult Create()
        {


            ViewData["items"] = _context.Categories.ToList();
            ViewData["items2"] = _context.Cities.ToList();
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            ViewData["items"] = _context.Categories.ToList();
            ViewData["items2"] = _context.Cities.ToList();

            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);
            product.AppuserID = activUser.Id;


            if (!ModelState.IsValid)
            {
                return View(product);
            }


            if (product.Photos == null)
            {
                ModelState.AddModelError("Photos", "sekil mutleq secilmedlir");
                return View(product);
            }
       
            product.CreatedAt = DateTime.Now;
            product.VezID = 2;
            await _context.Products.AddAsync(product);


            if (product.Photos.Count > 0)
            {
                foreach (var formFileImg in product.Photos)
                {
                    if (formFileImg.IsImage())
                    {
                        ProductImage productImges = new ProductImage();
                        productImges.Name = await formFileImg.SaveFileAsync(_env.WebRootPath);
                        productImges.ProductID = product.Id;
                        await  _context.ProductImages.AddAsync(productImges);
                    }
                    else
                    {
                        ModelState.AddModelError("Photos", "sekil duzgun secilmedlir");
                        return View(product);
                    }
                }
            }

            await _context.SaveChangesAsync();

            return RedirectToAction("MyProduct", "Account");
        }


    }
}