﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProjects.Models
{
    public class Product
    {
        public int Id { get; set; }

        [StringLength(200, ErrorMessage = "Basliq üçün nəzərdə tutulmuş mətin 200 simvoldan çox ola bilməz"),
        Required(ErrorMessage = "Başlıq boş buraxila bilməz")]
        public string Head { get; set; }

        [Required(ErrorMessage = "Məbləg bos buraxila bilməz")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Məzmun bos buraxila bilməz"), MinLength(10, ErrorMessage = "Məzmun minumum 10 simvoldan ibarət olmalidi")]
        public string Description { get; set; }

        [StringLength(20), Required(ErrorMessage = "Ad boş buraxila bilməz")]
        public string Name { get; set; }

        [StringLength(15), Required(ErrorMessage = "Nömrə bos buraxila bilməz")]
        public string Number { get; set; }
        public string Email { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdateAt { get; set; }
        public int SeeCount { get; set; }

        [NotMapped]
        public  List<IFormFile> Photos { get; set; }
        public int SubcategoryID { get; set; }
        public int CityID { get; set; }
        public string AppuserID { get; set; }
        public int VezID { get; set; }

        public virtual City City { get; set; }
        public virtual Subcategory Subcategory { get; set; }
        public virtual IEnumerable<ProductImage> ProductImages { get; set; }
    }
}
