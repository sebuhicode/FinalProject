﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FinalProjects.Models
{
    public class TexnikiDestek
    {
        public int Id { get; set; }
        [StringLength(100),Required]
        public string Head { get; set; }
        [Required]
        public DateTime CreatedAT { get; set; }
        public string UserID { get; set; }
        public int  VezID { get; set; }

    }
}
