﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProjects.ViewsModel
{
    public class LoginVm
    {
        [Required(ErrorMessage = "Email doldurulmalıdır ")]
        [MinLength(5)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }



        [Required(ErrorMessage = "Şifrə doldurulmalıdır")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool RememberMe { get; set; }

    }
}
